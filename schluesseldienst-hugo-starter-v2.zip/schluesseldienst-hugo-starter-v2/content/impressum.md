---
title: "Impressum"
---

**Angaben gemäß § 5 TMG**  
Schlüsseldienst Musterstadt  
Beispielstraße 12  
12345 Musterstadt

**Kontakt**  
Telefon: +49 123 4567890  
E-Mail: kontakt@schluesseldienst-musterstadt.de

**Umsatzsteuer-ID**  
(DE) Muster-Nummer

**Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV**  
Max Mustermann, Beispielstraße 12, 12345 Musterstadt
