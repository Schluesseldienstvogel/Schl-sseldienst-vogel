---
title: "Datenschutzerklärung"
---

Hier entsteht die Datenschutzerklärung. Ergänzen Sie Angaben zu: Verantwortlicher, Zweck, Rechtsgrundlage, Server-Logs, Kontaktformular (Netlify Forms), Auftragsverarbeiter (z. B. Netlify, CDN), Speicherdauer, Rechte der Betroffenen.
